"""Adapter implementations."""
