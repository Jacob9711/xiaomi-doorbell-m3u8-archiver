"""Mock adapters for tests."""
